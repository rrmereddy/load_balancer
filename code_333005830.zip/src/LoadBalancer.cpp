/**
 * @file LoadBalancer.cpp
 * @brief Implements the LoadBalancer class.
 */

#include "LoadBalancer.h"
#include "Logger.h"
#include <iterator>
#include <sstream>

/**
 * @brief Constructs a load balancer with an initial server pool.
 * @param initialServers Number of servers to create initially.
 * @param balancerLabel Human-readable balancer label used in logs.
 */
LoadBalancer::LoadBalancer(int initialServers, const std::string& balancerLabel)
: requestQueue_(),
  servers_(),
  clock_(0),
  nextServerId_(1),
  totalRequests_(0),
  totalRequestsHandled_(0),
  pendingScaleDown_(0),
  totalServersAdded_(0),
  totalServersRemoved_(0),
  balancerLabel_(balancerLabel.empty() ? "LoadBalancer" : balancerLabel) {
    if (initialServers < 0) {
        initialServers = 0;
    }
    for (int i = 0; i < initialServers; ++i) {
        servers_.push_back(WebServer(nextServerId_++));
    }
}

int LoadBalancer::getServerCount() const {
    return static_cast<int>(servers_.size());
}

/**
 * @brief Gets the number of queued requests.
 * @return Current queue length.
 */
std::size_t LoadBalancer::getQueueSize() const {
    return requestQueue_.size();
}

/**
 * @brief Gets a copy of the first queued requests.
 * @param maxItems Maximum number of requests to include.
 * @return Snapshot vector of queued requests.
 */
std::vector<Request> LoadBalancer::getQueueSnapshot(std::size_t maxItems) const {
    std::vector<Request> snapshot;
    if (maxItems == 0 || requestQueue_.empty()) {
        return snapshot;
    }

    std::queue<Request> queueCopy = requestQueue_;
    while (!queueCopy.empty() && snapshot.size() < maxItems) {
        snapshot.push_back(queueCopy.front());
        queueCopy.pop();
    }
    return snapshot;
}

/**
 * @brief Gets the current snapshot of all servers.
 * @return Vector with one snapshot entry per server.
 */
std::vector<ServerSnapshot> LoadBalancer::getServerSnapshots() const {
    std::vector<ServerSnapshot> snapshot;
    snapshot.reserve(servers_.size());
    for (const auto& server : servers_) {
        ServerSnapshot item;
        item.id = server.getId();
        item.busy = server.isBusy();
        item.request = item.busy ? server.getCurrentRequest() : Request();
        snapshot.push_back(item);
    }
    return snapshot;
}

/**
 * @brief Gets number of busy servers.
 * @return Count of active servers.
 */
int LoadBalancer::getActiveServerCount() const {
    int active = 0;
    for (const auto& server : servers_) {
        if (server.isBusy()) {
            ++active;
        }
    }
    return active;
}

/**
 * @brief Gets number of idle servers.
 * @return Count of inactive servers.
 */
int LoadBalancer::getIdleServerCount() const {
    return static_cast<int>(servers_.size()) - getActiveServerCount();
}

/**
 * @brief Adds a request to the queue and increments totals.
 * @param request Request to enqueue.
 */
void LoadBalancer::enqueueRequest(const Request& request) {
    requestQueue_.push(request);
    ++totalRequests_;
}

/**
 * @brief Checks whether any work remains to be processed.
 * @return True when queue is non-empty or a server is busy.
 */
bool LoadBalancer::hasPendingRequests() const {
    if (!requestQueue_.empty()) {
        return true;
    }
    for (const auto& server : servers_) {
        if (server.isBusy()) {
            return true;
        }
    }

    return false;
}

/**
 * @brief Dispatches queued work and advances active server requests.
 * @param logger Logger used for dispatch/progress/completion messages.
 * @return True when at least one queued request was assigned this cycle.
 */
bool LoadBalancer::dispatchToServers(Logger& logger) {
    bool dispatched = false;

    for (auto& server : servers_) {
        if (server.isBusy()) {
            if (server.handleRequest()) {
                std::ostringstream line;
                line << "Clock " << clock_ << ": " << formatServerTag(server)
                     << " completed request from " << server.getCurrentRequest().ipIn << " to " << server.getCurrentRequest().ipOut;
                logger.log(line.str());
                server.clearRequest();
                ++totalRequestsHandled_;
                continue;
            }
            std::ostringstream line;
            line << "Clock " << clock_ << ": " << formatServerTag(server)
                 << " working on request from " << server.getCurrentRequest().ipIn << " to " << server.getCurrentRequest().ipOut
                 << " finishing in " << server.getCurrentRequest().timeCycles << " cycles";
            logger.log(line.str());
            continue;
        }

        if (requestQueue_.empty()) {
            continue;
        }

        Request request = requestQueue_.front();
        requestQueue_.pop();
        server.assignRequest(request);

        std::ostringstream line;
        line << "Clock " << clock_ << ": " << formatServerTag(server)
             << " assigned request from " << request.ipIn << " to " << request.ipOut;
        logger.log(line.str());

        dispatched = true;
    }

    processDeferredScaleDown(logger);

    return dispatched;
}

/**
 * @brief Advances the balancer clock by one cycle.
 */
void LoadBalancer::tick() {
    ++clock_;
}

/**
 * @brief Adds one new server to the pool.
 */
void LoadBalancer::addServer() {
    servers_.push_back(WebServer(nextServerId_++));
}

/**
 * @brief Removes one idle server, preferring most recently added.
 */
void LoadBalancer::removeServer() {
    for (auto it = servers_.rbegin(); it != servers_.rend(); ++it) {
        if (!it->isBusy()) {
            servers_.erase(std::next(it).base());
            return;
        }
    }
}

/**
 * @brief Gets the current clock value.
 * @return Simulation clock.
 */
int LoadBalancer::getClock() const {
    return clock_;
}

/**
 * @brief Applies auto-scaling rules based on queue-per-server ratio.
 * @param minQueuePerServer Threshold below which scale-down is considered.
 * @param maxQueuePerServer Threshold above which scale-up is triggered.
 * @param logger Logger used for scaling event messages.
 */
void LoadBalancer::evaluateScaling(int minQueuePerServer, int maxQueuePerServer, Logger& logger) {
    const std::size_t queueSize = requestQueue_.size();
    const int serverCount = static_cast<int>(servers_.size());

    if (serverCount == 0) {
        if (queueSize > 0) {
            addServer();
            ++totalServersAdded_;
            std::ostringstream line;
            line << "Clock " << clock_ << ": [" << balancerLabel_
                 << "] Scale up -> added server, total servers: " << servers_.size();
            logger.log(line.str());
        }
        return;
    }

    double queuePerServer = static_cast<double>(queueSize) / static_cast<double>(serverCount);
    if (queuePerServer > static_cast<double>(maxQueuePerServer)) {
        int addedServers = 0;

        if (maxQueuePerServer <= 0) {
            addServer();
            ++addedServers;
        } else {
            while (!servers_.empty() && queuePerServer > static_cast<double>(maxQueuePerServer)) {
                addServer();
                ++addedServers;
                queuePerServer =static_cast<double>(queueSize) / static_cast<double>(servers_.size());
            }
        }

        std::ostringstream line;
        line << "Clock " << clock_ << ": [" << balancerLabel_ << "] Scale up -> added " << addedServers
             << " server(s), average queue per server is " << queuePerServer
             << ", total servers: " << servers_.size();
        logger.log(line.str());
        if (addedServers > 0) {
            totalServersAdded_ += addedServers;
        }
        return;
    }
    if (queuePerServer < static_cast<double>(minQueuePerServer)) {
        if (!removeOneIdleServer(logger)) {
            ++pendingScaleDown_;
            std::ostringstream line;
            line << "Clock " << clock_ << ": [" << balancerLabel_
                 << "] Scale down deferred -> no idle server available, pending removals: "
                 << pendingScaleDown_;
            logger.log(line.str());
        }
    }
}

/**
 * @brief Removes one idle server if available.
 * @param logger Logger for removal events.
 * @return True if a server was removed, false otherwise.
 */
bool LoadBalancer::removeOneIdleServer(Logger& logger) {
    for (auto it = servers_.rbegin(); it != servers_.rend(); ++it) {
        if (!it->isBusy()) {
            const int removedServerId = it->getId();
            servers_.erase(std::next(it).base());

            std::ostringstream line;
            line << "Clock " << clock_ << ": [" << balancerLabel_ << "] Scale down -> removed idle server "
                 << removedServerId
                 << ", total servers: " << servers_.size();
            logger.log(line.str());
            ++totalServersRemoved_;
            return true;
        }
    }
    return false;
}

/**
 * @brief Processes pending scale-down requests once servers become idle.
 * @param logger Logger for scale-down events.
 */
void LoadBalancer::processDeferredScaleDown(Logger& logger) {
    while (pendingScaleDown_ > 0) {
        if (!removeOneIdleServer(logger)) {
            return;
        }
        --pendingScaleDown_;
    }
}

/**
 * @brief Gets total accepted request count.
 * @return Number of accepted requests.
 */
int LoadBalancer::getTotalRequestsCount() const {
    return totalRequests_;
}

/**
 * @brief Gets total completed request count.
 * @return Number of handled requests.
 */
int LoadBalancer::getTotalRequestsHandledCount() const {
    return totalRequestsHandled_;
}

/**
 * @brief Gets total number of requests remaining.
 * @return Total requests remaining.
 */
int LoadBalancer::getTotalRequestsRemainingCount() const {
    return totalRequests_ - totalRequestsHandled_;
}

/**
 * @brief Gets total number of servers added by scaling.
 * @return Number of added servers.
 */
int LoadBalancer::getTotalServersAddedCount() const {
    return totalServersAdded_;
}

/**
 * @brief Gets total number of servers removed by scaling.
 * @return Number of removed servers.
 */
int LoadBalancer::getTotalServersRemovedCount() const {
    return totalServersRemoved_;
}

/**
 * @brief Formats a server tag for consistent logging output.
 * @param server Server to describe.
 * @return String tag with balancer label and server id.
 */
std::string LoadBalancer::formatServerTag(const WebServer& server) const {
    return "[" + balancerLabel_ + "] Server " + std::to_string(server.getId());
}
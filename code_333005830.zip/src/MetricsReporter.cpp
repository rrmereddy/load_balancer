/**
 * @file MetricsReporter.cpp
 * @brief Implements simulation metrics aggregation and reporting.
 */

#include "MetricsReporter.h"

#include "Logger.h"
#include "Request.h"
#include <algorithm>
#include <iomanip>
#include <sstream>
#include <string>
#include <vector>

namespace {

const int kTaskTimeMinCycles = 1;
const int kTaskTimeMaxCycles = 10;
const std::size_t kQueueSampleSize = 8;
const std::size_t kServerSampleSize = 8;

/**
 * @brief Formats a request as a concise log string.
 * @param request Request to format.
 * @return Formatted request line.
 */
std::string formatRequestForLog(const Request& request) {
    std::ostringstream line;
    line << request.ipIn << " -> " << request.ipOut
         << " | type=" << jobTypeToString(request.jobType)
         << " | time=" << request.timeCycles;
    return line.str();
}

/**
 * @brief Formats a floating-point value with fixed precision.
 * @param value Value to format.
 * @param precision Decimal precision to use.
 * @return String representation of the value.
 */
std::string formatDouble(double value, int precision = 2) {
    std::ostringstream stream;
    stream << std::fixed << std::setprecision(precision) << value;
    return stream.str();
}

/**
 * @brief Logs a snapshot of the balancer queue.
 * @param logger Logger used for output.
 * @param balancer Balancer whose queue is sampled.
 * @param title Prefix title for this snapshot.
 * @param maxItems Maximum queued requests to print.
 */
void logQueueSnapshot(Logger& logger, const LoadBalancer& balancer, const std::string& title, std::size_t maxItems) {
    logger.log(title + " queue size: " + std::to_string(balancer.getQueueSize()));
    const std::vector<Request> snapshot = balancer.getQueueSnapshot(maxItems);

    if (snapshot.empty()) {
        logger.log(title + " queue sample: [empty]");
        return;
    }

    logger.log(title + " queue sample (first " + std::to_string(snapshot.size()) + " request(s)):");
    for (std::size_t i = 0; i < snapshot.size(); ++i) {
        logger.log("  [" + std::to_string(i + 1) + "] " + formatRequestForLog(snapshot[i]));
    }
}

/**
 * @brief Logs a snapshot of server utilization and sampled assignments.
 * @param logger Logger used for output.
 * @param balancer Balancer whose servers are sampled.
 * @param title Prefix title for this snapshot.
 * @param maxItems Maximum servers to print.
 */
void logServerSnapshot(Logger& logger, const LoadBalancer& balancer, const std::string& title, std::size_t maxItems) {
    const std::vector<ServerSnapshot> snapshots = balancer.getServerSnapshots();
    logger.log(title + " server snapshot: active=" + std::to_string(balancer.getActiveServerCount()) +
               ", inactive=" + std::to_string(balancer.getIdleServerCount()) +
               ", total=" + std::to_string(balancer.getServerCount()));

    if (snapshots.empty()) {
        logger.log("  [no servers available]");
        return;
    }

    const std::size_t sampleCount = std::min(maxItems, snapshots.size());
    for (std::size_t i = 0; i < sampleCount; ++i) {
        const ServerSnapshot& server = snapshots[i];
        if (!server.busy) {
            logger.log("  Server " + std::to_string(server.id) + ": idle");
            continue;
        }
        logger.log("  Server " + std::to_string(server.id) + ": busy -> " + formatRequestForLog(server.request));
    }
}

} // namespace

/**
 * @brief Initializes metrics from the balancer's starting state.
 * @param balancer Balancer to initialize metrics for.
 * @return Initialized metrics structure.
 */
LoadBalancerMetrics initializeMetrics(const LoadBalancer& balancer) {
    const std::size_t startingQueueSize = balancer.getQueueSize();
    LoadBalancerMetrics metrics;
    metrics.startingQueueSize = startingQueueSize;
    metrics.peakQueueSize = startingQueueSize;
    metrics.queueSizeAccumulator = static_cast<long long>(startingQueueSize);
    metrics.queueSamples = 1;
    metrics.totalIncomingRequests = 0;
    metrics.totalRejectedRequests = 0;
    metrics.minServersObserved = balancer.getServerCount();
    metrics.maxServersObserved = balancer.getServerCount();
    return metrics;
}

/**
 * @brief Updates metrics after one simulation cycle.
 * @param metrics Metrics object to mutate.
 * @param balancer Balancer providing state values.
 * @param acceptedRequests Accepted requests for this cycle.
 * @param rejectedRequests Rejected requests for this cycle.
 */
void updateMetrics(
    LoadBalancerMetrics& metrics,
    const LoadBalancer& balancer,
    int acceptedRequests,
    int rejectedRequests) {
    metrics.totalIncomingRequests += acceptedRequests;
    metrics.totalRejectedRequests += rejectedRequests;
    const std::size_t queueSize = balancer.getQueueSize();
    metrics.peakQueueSize = std::max(metrics.peakQueueSize, queueSize);
    metrics.queueSizeAccumulator += static_cast<long long>(queueSize);
    ++metrics.queueSamples;
    metrics.minServersObserved = std::min(metrics.minServersObserved, balancer.getServerCount());
    metrics.maxServersObserved = std::max(metrics.maxServersObserved, balancer.getServerCount());
}

/**
 * @brief Logs the start-of-run snapshot for a balancer.
 * @param logger Logger used for output.
 * @param label Balancer label for log scoping.
 * @param balancer Balancer being reported.
 * @param initialServers Starting server count for this balancer.
 * @param runCycles Requested run length.
 * @param initialRequestCount Initial accepted request count.
 */
void logSimulationStartSnapshot(
    Logger& logger,
    const std::string& label,
    const LoadBalancer& balancer,
    int initialServers,
    int runCycles,
    int initialRequestCount) {
    const std::string prefix = "[" + label + "] ";
    logger.log(prefix + "=== Simulation Start Snapshot ===");
    logger.log(prefix + "");
    logger.log(prefix + "Run Config");
    logger.log(prefix + "  Initial servers: " + std::to_string(initialServers));
    logger.log(prefix + "  Run cycles: " + std::to_string(runCycles));
    logger.log(prefix + "  Task time range (cycles): " + std::to_string(kTaskTimeMinCycles) + "-" +
               std::to_string(kTaskTimeMaxCycles));
    logger.log(prefix + "");
    logger.log(prefix + "Starting State");
    logger.log(prefix + "  Requests at start: " + std::to_string(initialRequestCount));
    logger.log(prefix + "  Queue size: " + std::to_string(balancer.getQueueSize()));
    logger.log(prefix + "");
    logQueueSnapshot(logger, balancer, prefix + "Start-of-log", kQueueSampleSize);
}

/**
 * @brief Logs the end-of-run summary for a balancer.
 * @param logger Logger used for output.
 * @param label Balancer label for log scoping.
 * @param balancer Balancer being reported.
 * @param metrics Aggregated run metrics.
 * @param initialServers Starting server count for this balancer.
 * @param cyclesRun Number of cycles completed.
 */
void logSimulationEndSummary(
    Logger& logger,
    const std::string& label,
    const LoadBalancer& balancer,
    const LoadBalancerMetrics& metrics,
    int initialServers,
    int cyclesRun) {
    const std::string prefix = "[" + label + "] ";
    const std::size_t endingQueueSize = balancer.getQueueSize();
    const int totalRequests = balancer.getTotalRequestsCount();
    const int requestsHandled = balancer.getTotalRequestsHandledCount();
    const int requestsRemaining = balancer.getTotalRequestsRemainingCount();

    const double averageQueueSize = metrics.queueSamples > 0
                                        ? static_cast<double>(metrics.queueSizeAccumulator) /
                                              static_cast<double>(metrics.queueSamples)
                                        : 0.0;
    const double throughputPerCycle = cyclesRun > 0
                                          ? static_cast<double>(requestsHandled) / static_cast<double>(cyclesRun)
                                          : 0.0;
    const double completionRatio = totalRequests > 0
                                       ? (100.0 * static_cast<double>(requestsHandled)) /
                                             static_cast<double>(totalRequests)
                                       : 0.0;
    const int totalGeneratedDuringRun = metrics.totalIncomingRequests + metrics.totalRejectedRequests;
    const int totalGeneratedIncludingInitial = totalRequests + metrics.totalRejectedRequests;
    const double rejectionRatio = totalGeneratedIncludingInitial > 0
                                      ? (100.0 * static_cast<double>(metrics.totalRejectedRequests)) /
                                            static_cast<double>(totalGeneratedIncludingInitial)
                                      : 0.0;

    logger.log(prefix + "=== Simulation End Summary ===");
    logger.log(prefix + "");
    logger.log(prefix + "Run");
    logger.log(prefix + "  Cycles run: " + std::to_string(cyclesRun));
    logger.log(prefix + "  Task time range (cycles): " + std::to_string(kTaskTimeMinCycles) + "-" +
               std::to_string(kTaskTimeMaxCycles));
    
    logger.log(prefix + "");
    logger.log(prefix + "Requests");
    logger.log(prefix + "  Accepted/enqueued total: " + std::to_string(totalRequests));
    logger.log(prefix + "  Accepted during run: " + std::to_string(metrics.totalIncomingRequests));
    logger.log(prefix + "  Generated during run: " + std::to_string(totalGeneratedDuringRun) + " (accepted + rejected)");
    logger.log(prefix + "  Handled/completed: " + std::to_string(requestsHandled));
    logger.log(prefix + "  Remaining at end: " + std::to_string(requestsRemaining));
    logger.log(prefix + "  Rejected/discarded: " + std::to_string(metrics.totalRejectedRequests));

    logger.log(prefix + "");
    logger.log(prefix + "Queue");
    logger.log(prefix + "  Start -> end size: " + std::to_string(metrics.startingQueueSize) + " -> " +
               std::to_string(endingQueueSize));
    logger.log(prefix + "  Peak size: " + std::to_string(metrics.peakQueueSize));
    logger.log(prefix + "  Average size: " + formatDouble(averageQueueSize));

    logger.log(prefix + "");
    logger.log(prefix + "Servers");
    logger.log(prefix + "  Count start -> end: " + std::to_string(initialServers) + " -> " +
               std::to_string(balancer.getServerCount()));
    logger.log(prefix + "  Count min/max observed: " + std::to_string(metrics.minServersObserved) + " / " +
               std::to_string(metrics.maxServersObserved));
    logger.log(prefix + "  End state active/inactive: " + std::to_string(balancer.getActiveServerCount()) + " / " +
               std::to_string(balancer.getIdleServerCount()));
    logger.log(prefix + "  Scaling added/removed: " + std::to_string(balancer.getTotalServersAddedCount()) + " / " +
               std::to_string(balancer.getTotalServersRemovedCount()));

    logger.log(prefix + "");
    logger.log(prefix + "Performance");
    logger.log(prefix + "  Throughput (handled/cycle): " + formatDouble(throughputPerCycle));
    logger.log(prefix + "  Completion ratio: " + formatDouble(completionRatio) + "%");
    logger.log(prefix + "  Rejection ratio: " + formatDouble(rejectionRatio) + "%");
    logger.log(prefix + "");

    logServerSnapshot(logger, balancer, prefix + "End-of-run", kServerSampleSize);
}
